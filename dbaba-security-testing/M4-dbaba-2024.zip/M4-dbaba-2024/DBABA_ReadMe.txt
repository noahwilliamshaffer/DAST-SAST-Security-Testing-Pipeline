In a Linux VM (these instructions work in Ubuntu): 
  1. Update (sudo apt update && sudo apt upgrade)
  2. Install python3 (sudo apt install python3)
  3. Install pycryptodome (sudo apt install python3-pycryptodome)
  4. Download to the Linux VM the M4-dbaba-2024.zip file your instructor will give you.
  5. Unzip the zip file. This will create a folder “M4-dbaba-2024”.
  6. Go to the dbaba folder in the M4-dbaba folder (cd M4-dbaba-2024/dbaba)
  7. Run the dbaba.py program (python3 dbaba.py)

Initially, there is only one user “admin” (“LIN admin”)

